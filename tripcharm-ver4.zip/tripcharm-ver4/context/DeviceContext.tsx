import React, { createContext, useContext, useEffect, useState } from "react";
import { useSettings } from "./SettingsContext"; // adjust path if needed

// Device type
export type Device = {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  lastSeen: number; // timestamp
};

type DeviceContextProps = {
  devices: Device[];
  isLoading: boolean;
  error: string | null;
  fetchDevices: () => void;
  updateDeviceLocation: (id: string, lat: number, lon: number) => void;
  addDevice: (device: Device) => void;
};

const DeviceContext = createContext<DeviceContextProps>({
  devices: [],
  isLoading: false,
  error: null,
  fetchDevices: () => {},
  updateDeviceLocation: () => {},
  addDevice: () => {},
});

export const DeviceProvider = ({ children }: { children: React.ReactNode }) => {
  const [devices, setDevices] = useState<Device[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { locationUpdateInterval = 30 } = useSettings(); // seconds, default 30

  // Dummy fetch function (replace with your API or data source)
  const fetchDevices = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Simulate fetch delay
      await new Promise((r) => setTimeout(r, 1000));
      // Example static devices, replace with real data fetching
      setDevices([
        {
          id: "device1",
          name: "Child's Phone",
          latitude: 1.3521,
          longitude: 103.8198,
          lastSeen: Date.now(),
        },
        {
          id: "device2",
          name: "Mom's Phone",
          latitude: 1.3550,
          longitude: 103.8200,
          lastSeen: Date.now(),
        },
      ]);
    } catch (e) {
      setError("Failed to fetch devices.");
    }
    setIsLoading(false);
  };

  // Simulate device location update every `locationUpdateInterval` seconds
  useEffect(() => {
    if (devices.length === 0) return;

    const interval = setInterval(() => {
      setDevices((prevDevices) =>
        prevDevices.map((device) => {
          // Random small delta for lat/lon
          const deltaLat = (Math.random() - 0.5) * 0.0005;
          const deltaLon = (Math.random() - 0.5) * 0.0005;
          return {
            ...device,
            latitude: device.latitude + deltaLat,
            longitude: device.longitude + deltaLon,
            lastSeen: Date.now(),
          };
        })
      );
    }, locationUpdateInterval * 1000);

    return () => clearInterval(interval);
  }, [devices.length, locationUpdateInterval]);

  // Function to update device location in state
  const updateDeviceLocation = (id: string, lat: number, lon: number) => {
    setDevices((prev) =>
      prev.map((d) =>
        d.id === id
          ? { ...d, latitude: lat, longitude: lon, lastSeen: Date.now() }
          : d
      )
    );
  };

  // Add a new device
  const addDevice = (device: Device) => {
    setDevices((prev) => [...prev, device]);
  };

  return (
    <DeviceContext.Provider
      value={{ devices, isLoading, error, fetchDevices, updateDeviceLocation, addDevice }}
    >
      {children}
    </DeviceContext.Provider>
  );
};

export const useDevices = () => useContext(DeviceContext);
