import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { v4 as uuidv4 } from "uuid";

export type GeofenceSchedule = {
  repeat: "none" | "daily" | "weekly" | "monthly" | "weekdays";
  weekdays: number[];
  startDate: Date | null;
  startTime: string | null;
  endTime: string | null;
};

export type Geofence = {
  id: string;
  type: "circle" | "polygon";
  name: string;
  center: { latitude: number; longitude: number } | null;
  radius: number;
  polygonPoints: { latitude: number; longitude: number }[];
  schedule: GeofenceSchedule;
};

type GeofenceContextType = {
  geofences: Geofence[];
  currentGeofence: Geofence | null;
  setCurrentGeofence: React.Dispatch<React.SetStateAction<Geofence | null>>;
  addGeofence: (g: Geofence) => void;
  updateGeofence: (g: Geofence) => void;
  deleteGeofence: (id: string) => void;
  loadFromStorage: () => void;
  undoPolygon: () => void;
  redoPolygon: () => void;
  clearPolygonPoints: () => void;
  canUndo: boolean;
  canRedo: boolean;
  startNewGeofence: () => void;
};

const STORAGE_KEY = "@myapp_geofences";

const GeofenceContext = createContext<GeofenceContextType | undefined>(undefined);

export const GeofenceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [geofences, setGeofences] = useState<Geofence[]>([]);
  const [currentGeofence, setCurrentGeofence] = useState<Geofence | null>(null);
  const undoStack = useRef<{ latitude: number; longitude: number }[][]>([]);
  const redoStack = useRef<{ latitude: number; longitude: number }[][]>([]);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  const updateUndoRedoState = () => {
    setCanUndo(undoStack.current.length > 0);
    setCanRedo(redoStack.current.length > 0);
  };

  // Load saved geofences on mount
  const loadFromStorage = async () => {
    try {
      const json = await AsyncStorage.getItem(STORAGE_KEY);
      if (json) {
        const saved: Geofence[] = JSON.parse(json).map((g: any) => ({
          ...g,
          schedule: {
            ...g.schedule,
            startDate: g.schedule.startDate ? new Date(g.schedule.startDate) : null,
          },
        }));
        setGeofences(saved);
        if (saved.length > 0) setCurrentGeofence(saved[0]);
      }
    } catch (e) {
      console.warn("Failed to load geofences", e);
    }
  };

  useEffect(() => {
    loadFromStorage();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(geofences)).catch((e) =>
      console.warn("Save error", e)
    );
  }, [geofences]);

  const addGeofence = (g: Geofence) => setGeofences((prev) => [...prev, g]);
  const updateGeofence = (g: Geofence) =>
    setGeofences((prev) => prev.map((x) => (x.id === g.id ? g : x)));
  const deleteGeofence = (id: string) => {
    setGeofences((prev) => prev.filter((g) => g.id !== id));
    if (currentGeofence?.id === id) setCurrentGeofence(null);
    undoStack.current = [];
    redoStack.current = [];
    updateUndoRedoState();
  };

  const startNewGeofence = () => {
    const newG: Geofence = {
      id: uuidv4(),
      name: "",
      type: "circle",
      center: { latitude: 1.3521, longitude: 103.8198 },
      radius: 100,
      polygonPoints: [],
      schedule: { repeat: "none", weekdays: [], startDate: new Date(), startTime: "00:00", endTime: "23:59" },
    };
    setCurrentGeofence(newG);
    undoStack.current = [];
    redoStack.current = [];
    updateUndoRedoState();
  };

  const undoPolygon = () => {
    if (!currentGeofence || undoStack.current.length === 0) return;
    const last = undoStack.current.pop()!;
    redoStack.current.push(currentGeofence.polygonPoints);
    setCurrentGeofence({ ...currentGeofence, polygonPoints: last });
    updateUndoRedoState();
  };

  const redoPolygon = () => {
    if (!currentGeofence || redoStack.current.length === 0) return;
    const next = redoStack.current.pop()!;
    undoStack.current.push(currentGeofence.polygonPoints);
    setCurrentGeofence({ ...currentGeofence, polygonPoints: next });
    updateUndoRedoState();
  };

  const clearPolygonPoints = () => {
    if (!currentGeofence) return;
    undoStack.current.push(currentGeofence.polygonPoints);
    redoStack.current = [];
    setCurrentGeofence({ ...currentGeofence, polygonPoints: [] });
    updateUndoRedoState();
  };

  useEffect(() => {
    if (!currentGeofence) return;
    const last = undoStack.current[undoStack.current.length - 1];
    if (!last || JSON.stringify(last) !== JSON.stringify(currentGeofence.polygonPoints)) {
      undoStack.current.push(currentGeofence.polygonPoints);
      redoStack.current = [];
      updateUndoRedoState();
    }
  }, [currentGeofence?.polygonPoints]);

  return (
    <GeofenceContext.Provider
      value={{
        geofences,
        currentGeofence,
        setCurrentGeofence,
        addGeofence,
        updateGeofence,
        deleteGeofence,
        loadFromStorage,
        undoPolygon,
        redoPolygon,
        clearPolygonPoints,
        canUndo,
        canRedo,
        startNewGeofence,
      }}
    >
      {children}
    </GeofenceContext.Provider>
  );
};

export const useGeofence = () => {
  const ctx = useContext(GeofenceContext);
  if (!ctx) throw new Error("useGeofence must be inside GeofenceProvider");
  return ctx;
};
